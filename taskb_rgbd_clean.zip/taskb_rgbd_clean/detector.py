"""RGB-D 检测: Head 抓取 + EE 导航认类。"""

from __future__ import annotations

from typing import List

import cv2
import numpy as np

from config import DEPTH_MAX, DEPTH_MIN, OBJECT_SIZES
from ee_nav import compute_ee_object, ee_nav_quality, reject_ee_blob, robust_depth as ee_robust_depth
from head_grasp import compute_head_pose, head_grasp_quality, reject_head_blob, robust_depth as head_robust_depth


def _bbox_iou(a: list[int], b: list[int]) -> float:
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    inter = max(0, ix2 - ix1 + 1) * max(0, iy2 - iy1 + 1)
    if inter <= 0:
        return 0.0
    ua = (ax2 - ax1 + 1) * (ay2 - ay1 + 1) + (bx2 - bx1 + 1) * (by2 - by1 + 1) - inter
    return inter / max(ua, 1)


class SimpleTracker:
    def __init__(self, iou_thresh: float = 0.25):
        self.iou_thresh = iou_thresh
        self._next_id = 0
        self._tracks: dict[int, list[int]] = {}
        self._class: dict[int, str] = {}

    def reset(self):
        self._next_id = 0
        self._tracks.clear()
        self._class.clear()

    def assign(self, bboxes: List[list[int]]) -> List[int]:
        ids = [-1] * len(bboxes)
        used = set()
        for i, bb in enumerate(bboxes):
            best_id, best_iou = None, 0.0
            for tid, tbb in self._tracks.items():
                if tid in used:
                    continue
                iou = _bbox_iou(bb, tbb)
                if iou > best_iou:
                    best_iou, best_id = iou, tid
            if best_id is not None and best_iou >= self.iou_thresh:
                ids[i] = best_id
                used.add(best_id)
                self._tracks[best_id] = bb
            else:
                ids[i] = self._next_id
                self._tracks[self._next_id] = bb
                self._next_id += 1
        for tid in [t for t in self._tracks if t not in used]:
            del self._tracks[tid]
            self._class.pop(tid, None)
        return ids

    def stabilize_class(self, oid: int, cls: str, conf: float, min_conf: float = 0.45) -> str:
        prev = self._class.get(oid)
        if prev and cls != prev and conf < min_conf + 0.12:
            return prev
        if cls:
            self._class[oid] = cls
        return cls


class RgbdDetector:
    def __init__(self, camera: str):
        if camera not in ("head", "ee"):
            raise ValueError(camera)
        self.camera = camera
        self.tracker = SimpleTracker()
        self._debug: dict[str, np.ndarray] = {}

    def reset(self):
        self.tracker.reset()
        self._debug.clear()

    def get_debug(self, name: str):
        return self._debug.get(name)

    def _build_fusion(self, hsv, sat, val, depth, h: int, w: int) -> np.ndarray:
        if self.camera == "head":
            yellow = cv2.inRange(hsv, (12, 36, 48), (50, 255, 255))
            sat_min, close_k = 32, 7
        else:
            # EE: 远距降低饱和度门槛 + hue 黄补检
            yellow = cv2.inRange(hsv, (12, 24, 42), (52, 255, 255))
            sat_min, close_k = 24, 5
            hue_y = cv2.inRange(hsv, (12, 14, 55), (50, 255, 255))
            yellow = cv2.bitwise_or(yellow, hue_y)

        valid = (depth > DEPTH_MIN) & (depth < DEPTH_MAX)
        ground = cv2.morphologyEx(
            np.where(valid, depth, 0).astype(np.float32),
            cv2.MORPH_OPEN,
            cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (19, 19)),
        )
        relief = np.clip(ground - depth, 0, None)
        relief_thr = 0.012 if self.camera == "head" else 0.010
        relief_mask = relief > relief_thr
        closer = depth < (ground - 0.01)
        near_fb = (sat >= sat_min) & (val >= 48) & valid & (depth < 1.65)
        far_pale = (sat >= 18) & (val >= 44) & valid & (depth >= 1.65) & (depth < 6.0)
        fusion = yellow & valid & (relief_mask | closer | near_fb | far_pale)

        if self.camera == "ee":
            far_mask = (depth >= 1.8) & valid
            dil_k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
            yellow_d = cv2.dilate(yellow.astype(np.uint8), dil_k)
            fusion = fusion | (yellow_d.astype(bool) & far_mask & (relief_mask | closer))

        fusion = cv2.morphologyEx(
            fusion.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((close_k, close_k), np.uint8),
        )
        self._debug = {
            "yellow": yellow if self.camera == "head" else yellow,
            "fusion": fusion,
            "relief": np.clip(relief * 80, 0, 255).astype(np.uint8),
        }
        return fusion

    def detect(self, rgb, depth, robot_pos, robot_yaw) -> List[dict]:
        h, w = depth.shape[:2]
        if rgb.shape[:2] != (h, w):
            rgb = cv2.resize(rgb, (w, h))

        hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)
        sat, val = hsv[:, :, 1], hsv[:, :, 2]
        fusion = self._build_fusion(hsv, sat, val, depth, h, w)

        n, _, stats, _ = cv2.connectedComponentsWithStats(fusion, connectivity=8)
        bboxes = []
        min_area = 24 if self.camera == "head" else 10
        min_side = 5 if self.camera == "head" else 3
        for i in range(1, n):
            x, y, bw, bh, area = stats[i]
            if area < min_area or min(bw, bh) < min_side:
                continue
            bbox = [x, y, x + bw - 1, y + bh - 1]
            if self.camera == "ee" and y + bh < h * 0.42:
                continue
            if self.camera == "head" and y + bh < h * 0.38:
                continue
            bboxes.append(bbox)

        ids = self.tracker.assign(bboxes)
        objects = []
        for bbox, oid in zip(bboxes, ids):
            obj = self._blob_to_object(bbox, fusion, depth, sat, val, fusion, robot_pos, robot_yaw, oid, h, w)
            if obj is not None:
                objects.append(obj)

        if self.camera == "head":
            objects.sort(key=lambda o: (-head_grasp_quality(o), o["depth_m"]))
        else:
            objects.sort(key=lambda o: (-ee_nav_quality(o), o["depth_m"]))
        return objects

    def _blob_to_object(self, bbox, fusion, depth, sat, val, relief, robot_pos, robot_yaw, oid, h, w):
        x1, y1, x2, y2 = bbox
        ys, xs = np.where(fusion > 0)
        ys = ys[(ys >= y1) & (ys <= y2)]
        xs = xs[(xs >= x1) & (xs <= x2)]
        if len(ys) < 6:
            return None

        sm = float(np.mean(sat[ys, xs]))
        vm = float(np.mean(val[ys, xs]))
        cx, cy = float(np.median(xs)), float(np.median(ys))

        if self.camera == "head":
            depth_m = head_robust_depth(ys, xs, depth, bbox)
            if depth_m is None or reject_head_blob(bbox, ys, xs, depth, sat, val, relief, h, w):
                return None
            pose = compute_head_pose(ys, xs, depth, depth_m, bbox, sm, robot_pos, robot_yaw)
            if pose is None:
                return None
            cls = self.tracker.stabilize_class(oid, pose["class"], pose.get("class_conf", 0))
            pose["class"] = cls
            return {
                "id": int(oid),
                "camera": "head",
                "role": "grasp",
                "bbox": bbox,
                "centroid_uv": [cx, cy],
                "blob_sat_mean": sm,
                "blob_val_mean": vm,
                "size_world": list(OBJECT_SIZES.get(cls, (0.15, 0.10, 0.10))),
                **pose,
            }

        depth_m = ee_robust_depth(ys, xs, depth, bbox)
        if depth_m is None or reject_ee_blob(bbox, ys, xs, depth, sat, val, cy, h, w):
            return None
        pose = compute_ee_object(ys, xs, depth, depth_m, bbox, sm, robot_pos, robot_yaw)
        if pose is None:
            return None
        cls = self.tracker.stabilize_class(oid, pose["class"], pose.get("class_conf", 0))
        pose["class"] = cls
        return {
            "id": int(oid),
            "camera": "ee",
            "role": "nav",
            "bbox": bbox,
            "blob_sat_mean": sm,
            "blob_val_mean": vm,
            "size_world": list(OBJECT_SIZES.get(cls, (0.15, 0.10, 0.10))),
            **pose,
        }
