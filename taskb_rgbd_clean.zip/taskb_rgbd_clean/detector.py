"""单路 RGB-D 检测: HSV 黄 + depth relief → 3D 物体。"""

from __future__ import annotations

from typing import List, Optional

import cv2
import numpy as np

from config import OBJECT_SIZES
from geometry import grasp_quat, object_pose_from_points, pixel_to_robot, points_from_mask, robot_to_world


def _classify_bbox(bbox: list[int]) -> str:
    x1, y1, x2, y2 = bbox
    w, h = max(x2 - x1 + 1, 1), max(y2 - y1 + 1, 1)
    asp = max(w, h) / min(w, h)
    if asp > 2.0:
        return "banana"
    if asp > 1.35:
        return "mustard_bottle"
    return "sugar_box"


def _bbox_iou(a: list[int], b: list[int]) -> float:
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    inter = max(0, ix2 - ix1 + 1) * max(0, iy2 - iy1 + 1)
    if inter <= 0:
        return 0.0
    ua = (ax2 - ax1 + 1) * (ay2 - ay1 + 1) + (bx2 - bx1 + 1) * (by2 - by1 + 1) - inter
    return inter / max(ua, 1)


class SimpleTracker:
    def __init__(self, iou_thresh: float = 0.25):
        self.iou_thresh = iou_thresh
        self._next_id = 0
        self._tracks: dict[int, list[int]] = {}

    def reset(self):
        self._next_id = 0
        self._tracks.clear()

    def assign(self, bboxes: List[list[int]]) -> List[int]:
        ids = [-1] * len(bboxes)
        used = set()
        for i, bb in enumerate(bboxes):
            best_id, best_iou = None, 0.0
            for tid, tbb in self._tracks.items():
                if tid in used:
                    continue
                iou = _bbox_iou(bb, tbb)
                if iou > best_iou:
                    best_iou, best_id = iou, tid
            if best_id is not None and best_iou >= self.iou_thresh:
                ids[i] = best_id
                used.add(best_id)
                self._tracks[best_id] = bb
            else:
                ids[i] = self._next_id
                self._tracks[self._next_id] = bb
                self._next_id += 1
        for tid in [t for t in self._tracks if t not in used]:
            del self._tracks[tid]
        return ids


class RgbdDetector:
    def __init__(self, camera: str):
        if camera not in ("head", "ee"):
            raise ValueError(camera)
        self.camera = camera
        self.tracker = SimpleTracker()
        self._debug: dict[str, np.ndarray] = {}

    def reset(self):
        self.tracker.reset()
        self._debug.clear()

    def get_debug(self, name: str):
        return self._debug.get(name)

    def detect(self, rgb, depth, robot_pos, robot_yaw) -> List[dict]:
        h, w = depth.shape[:2]
        if rgb.shape[:2] != (h, w):
            rgb = cv2.resize(rgb, (w, h))

        hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)
        sat, val = hsv[:, :, 1], hsv[:, :, 2]
        yellow = cv2.inRange(hsv, (12, 40, 50), (50, 255, 255))

        valid = (depth > 0.14) & (depth < 11.0)
        ground = cv2.morphologyEx(
            np.where(valid, depth, 0).astype(np.float32),
            cv2.MORPH_OPEN,
            cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (19, 19)),
        )
        relief = np.clip(ground - depth, 0, None)
        relief_mask = relief > (0.012 if self.camera == "head" else 0.010)
        closer = depth < (ground - 0.01)
        fusion = yellow & valid & (relief_mask | closer)
        fusion = cv2.morphologyEx(fusion.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))

        self._debug = {
            "yellow": yellow,
            "fusion": fusion,
            "relief": np.clip(relief * 80, 0, 255).astype(np.uint8),
        }

        n, _, stats, _ = cv2.connectedComponentsWithStats(fusion, connectivity=8)
        bboxes = []
        for i in range(1, n):
            x, y, bw, bh, area = stats[i]
            if area < 20 or min(bw, bh) < 4:
                continue
            if y + bh < h * 0.45:
                continue
            bboxes.append([x, y, x + bw - 1, y + bh - 1])

        ids = self.tracker.assign(bboxes)
        objects = []
        for bbox, oid in zip(bboxes, ids):
            obj = self._blob_to_object(bbox, fusion, depth, sat, val, robot_pos, robot_yaw, oid)
            if obj is not None:
                objects.append(obj)
        objects.sort(key=lambda o: o["depth_m"])
        return objects

    def _blob_to_object(self, bbox, fusion, depth, sat, val, robot_pos, robot_yaw, oid):
        x1, y1, x2, y2 = bbox
        ys, xs = np.where(fusion > 0)
        ys = ys[(ys >= y1) & (ys <= y2)]
        xs = xs[(xs >= x1) & (xs <= x2)]
        if len(ys) < 8:
            return None

        dvals = depth[ys, xs]
        dvals = dvals[(dvals > 0.14) & (dvals < 11.0)]
        if len(dvals) < 5:
            return None
        depth_m = float(np.median(dvals))

        cls = _classify_bbox(bbox)
        cx, cy = float(np.median(xs)), float(np.median(ys))
        sm, vm = float(np.mean(sat[ys, xs])), float(np.mean(val[ys, xs]))

        pts = points_from_mask(ys, xs, depth, self.camera)
        if pts is not None:
            pose = object_pose_from_points(pts, robot_pos, robot_yaw, cls)
        else:
            pos_r = pixel_to_robot(cx, cy, depth_m, self.camera)
            if pos_r[2] < -0.75 or pos_r[2] > 0.30:
                return None
            pos_w = robot_to_world(pos_r, robot_pos, robot_yaw)
            pose = {
                "pos_robot": pos_r.tolist(),
                "pos_world": pos_w.tolist(),
                "dist_to_robot": float(np.linalg.norm(pos_r[:2])),
                "yaw_rel": float(np.arctan2(pos_r[1], pos_r[0])),
            }
            if self.camera == "head":
                grasp = pos_r.copy()
                grasp[2] -= 0.03
                pose["grasp_pos_robot"] = grasp.tolist()
                pose["grasp_pos_world"] = robot_to_world(grasp, robot_pos, robot_yaw).tolist()
                pose["grasp_quat_world"] = grasp_quat(cls, pos_w, robot_pos).tolist()

        out = {
            "id": int(oid),
            "camera": self.camera,
            "class": cls,
            "conf": float(min(0.95, 0.5 + sm / 200.0)),
            "bbox": bbox,
            "centroid_uv": [cx, cy],
            "depth_m": depth_m,
            "blob_sat_mean": sm,
            "blob_val_mean": vm,
            "size_world": list(OBJECT_SIZES.get(cls, (0.15, 0.10, 0.10))),
            **pose,
        }
        if self.camera == "ee":
            out.pop("grasp_pos_world", None)
            out.pop("grasp_quat_world", None)
            out.pop("grasp_pos_robot", None)
        return out
