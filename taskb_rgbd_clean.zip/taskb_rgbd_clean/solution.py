"""比赛 AlgSolution — 感知输出在 result['perception']。"""

from __future__ import annotations

from typing import Any

from pipeline import DualRgbdPipeline


class AlgSolution:
    def __init__(self):
        self.pipeline = DualRgbdPipeline()
        self.last_perception = None

    def reset(self):
        self.pipeline.reset()
        self.last_perception = None

    def get_action_spec(self) -> dict[str, dict[str, Any]] | None:
        return None

    def get_perception(self, obs: dict) -> dict:
        self.last_perception = self.pipeline.process(obs)
        return self.last_perception

    def predicts(self, obs, current_score):
        perception = self.get_perception(obs)
        proprio = obs["proprio"]
        dim = (int(proprio.shape[-1]) - 12) // 3 if hasattr(proprio, "shape") else 20
        return {"action": [0.0] * dim, "giveup": False, "perception": perception}
