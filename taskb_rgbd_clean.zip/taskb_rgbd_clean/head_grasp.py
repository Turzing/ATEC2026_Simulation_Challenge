"""Head 高精度抓取: 点云滤波 + 底边 anchor + 抓取点。"""

from __future__ import annotations

from typing import List, Optional, Tuple

import numpy as np

from classify import classify_object
from config import (
    DEPTH_MAX,
    DEPTH_MIN,
    GRASP_DEPTH_OFFSET,
    GRASP_Z_PERCENTILE,
    HEAD_BOTTOM_FRAC,
    HEAD_CENTER_Z_PCT,
    HEAD_DEPTH_POINT_TOL,
    HEAD_MAX_DEPTH_STD,
    HEAD_MIN_BLOB_SAT,
    HEAD_MIN_BLOB_VAL,
    HEAD_MIN_GRASP_CONF,
    HEAD_MIN_POINTS,
    MIN_HEAD_POINTS,
)
from geometry import (
    compensate_gripper_base,
    grasp_quat,
    pixel_to_robot,
    points_from_mask,
    robot_to_world,
)


def filter_pixels_by_depth(ys, xs, depth, depth_m: float):
    d = depth[ys, xs]
    ok = (d > DEPTH_MIN) & (d < DEPTH_MAX)
    if int(np.sum(ok)) < MIN_HEAD_POINTS:
        return ys, xs
    d_med = float(np.median(d[ok]))
    tol = HEAD_DEPTH_POINT_TOL
    keep = ok & (d <= d_med + tol) & (d >= d_med - tol * 0.55)
    if int(np.sum(keep)) >= max(6, MIN_HEAD_POINTS // 2):
        return ys[keep], xs[keep]
    return ys, xs


def build_pointcloud(ys, xs, depth, depth_m: float) -> Optional[np.ndarray]:
    ys, xs = filter_pixels_by_depth(ys, xs, depth, depth_m)
    return points_from_mask(ys, xs, depth, "head", z_min=DEPTH_MIN, z_max=DEPTH_MAX)


def robust_depth(ys, xs, depth, bbox: List[int]) -> Optional[float]:
    d = depth[ys, xs]
    d = d[(d > DEPTH_MIN) & (d < DEPTH_MAX)]
    if len(d) < 4:
        return None
    d_mask = float(np.percentile(d, 38))
    x1, y1, x2, y2 = bbox
    iw, ih = max(1, x2 - x1 + 1), max(1, y2 - y1 + 1)
    inner = depth[y1 + ih // 4 : y2 - ih // 4 + 1, x1 + iw // 4 : x2 - iw // 4 + 1]
    inner = inner[(inner > DEPTH_MIN) & (inner < DEPTH_MAX)]
    d_inner = float(np.median(inner)) if len(inner) >= 3 else d_mask
    return float(np.median([d_mask, d_inner]))


def is_shadow(ys, xs, sat, val, relief, area: int, h: int, w: int) -> bool:
    if len(ys) < 5:
        return False
    sm = float(np.mean(sat[ys, xs]))
    vm = float(np.mean(val[ys, xs]))
    rm = float(np.median(relief[ys, xs])) if relief is not None else 0.02
    bw = int(xs.max() - xs.min() + 1)
    bh = int(ys.max() - ys.min() + 1)
    asp = max(bw, bh) / max(min(bw, bh), 1)
    if area > 500 and sm < 42 and vm < 72 and rm < 0.008:
        return True
    if area > 1200 and asp > 1.8 and sm < 44 and vm < 84 and rm < 0.007:
        return True
    return False


def is_edge_phantom(bbox: List[int], depth_m: float, img_w: int = 640) -> bool:
    x1, y1, x2, y2 = bbox
    cx = 0.5 * (x1 + x2)
    bw = x2 - x1 + 1
    if cx > img_w * 0.78 or cx < img_w * 0.22:
        return True
    if (cx > img_w * 0.72 or cx < img_w * 0.28) and bw < img_w * 0.24 and depth_m < 2.2:
        return True
    return False


def near_depth_anchor(ys, xs, depth) -> Tuple[float, float, float]:
    """近端 depth 像素 anchor (p10), 避免 bbox 底边打到地面."""
    blob_d = depth[ys, xs]
    blob_d = blob_d[(blob_d > DEPTH_MIN) & (blob_d < DEPTH_MAX)]
    if blob_d.size >= 6:
        az = float(np.percentile(blob_d, 10))
        idx = int(np.argmin(np.abs(blob_d - az)))
        return float(xs[idx]), float(ys[idx]), az
    cx, cy = float(np.median(xs)), float(np.median(ys))
    az = float(np.median(blob_d)) if blob_d.size else 0.0
    return cx, cy, az


def compute_head_pose(
    ys,
    xs,
    depth,
    depth_m: float,
    bbox: List[int],
    sat_mean: float,
    robot_pos: np.ndarray,
    robot_yaw: float,
) -> Optional[dict]:
    pts = build_pointcloud(ys, xs, depth, depth_m)
    nav_u, nav_v, az = near_depth_anchor(ys, xs, depth)
    area = len(ys)

    if pts is not None and len(pts) >= HEAD_MIN_POINTS:
        y_cut = float(np.quantile(ys.astype(np.float32), HEAD_BOTTOM_FRAC))
        bot = ys >= y_cut
        if int(np.sum(bot)) >= 6:
            pts_bot = build_pointcloud(ys[bot], xs[bot], depth, depth_m)
            if pts_bot is not None and len(pts_bot) >= 6:
                center = np.median(pts_bot, axis=0).astype(np.float32)
                center[2] = float(np.percentile(pts[:, 2], HEAD_CENTER_Z_PCT))
            else:
                center = np.median(pts, axis=0).astype(np.float32)
        else:
            center = np.median(pts, axis=0).astype(np.float32)
        point_count = len(pts)
        from_pc = True
    else:
        depth_use = az if az > DEPTH_MIN else depth_m
        center = pixel_to_robot(nav_u, nav_v, depth_use, "head")
        if center is None:
            return None
        pts = center.reshape(1, 3)
        point_count = area
        from_pc = False

    if float(center[2]) < -0.78 or float(center[2]) > 0.28:
        return None

    grasp = center.copy()
    if pts is not None and len(pts) >= 8:
        grasp[2] = float(np.percentile(pts[:, 2], GRASP_Z_PERCENTILE)) - GRASP_DEPTH_OFFSET
    else:
        grasp[2] = float(center[2]) - GRASP_DEPTH_OFFSET

    cls, cls_conf, geom_ext = classify_object(bbox, area, pts if from_pc else None, sat_mean, depth_m)
    pos_w = robot_to_world(center, robot_pos, robot_yaw)
    grasp_w = robot_to_world(grasp, robot_pos, robot_yaw)
    gq = grasp_quat(cls, pos_w, robot_pos)

    depth_f = float(az if az > DEPTH_MIN else depth_m)
    conf = float(min(0.94, 0.45 + cls_conf * 0.55))
    grasp_reliable = from_pc and point_count >= HEAD_MIN_POINTS and cls_conf >= HEAD_MIN_GRASP_CONF

    out = {
        "class": cls,
        "class_conf": cls_conf,
        "conf": conf,
        "pos_robot": center.tolist(),
        "pos_world": pos_w.tolist(),
        "grasp_pos_robot": grasp.tolist(),
        "grasp_pos_world": grasp_w.tolist(),
        "grasp_quat_world": gq.tolist(),
        "grasp_offset_robot": (grasp - center).tolist(),
        "dist_to_robot": float(np.linalg.norm(center[:2])),
        "yaw_rel": float(np.arctan2(center[1], center[0])),
        "depth_m": depth_f,
        "nav_depth_m": depth_f,
        "nav_anchor_uv": [nav_u, nav_v],
        "nav_anchor_depth": az,
        "nav_point_count": point_count,
        "pos_from_pointcloud": from_pc,
        "grasp_reliable": grasp_reliable,
        "world_reliable": from_pc and depth_f < 2.0,
    }
    if geom_ext is not None:
        out["geom_extents"] = geom_ext
    return compensate_gripper_base(out, robot_pos, robot_yaw)


def head_grasp_quality(obj: dict) -> float:
    q = float(obj.get("class_conf", 0)) * 120.0
    q += float(obj.get("blob_sat_mean", 0)) * 0.45
    q += float(obj.get("nav_point_count", 0)) * 0.35
    if obj.get("grasp_reliable"):
        q += 100.0
    if obj.get("pos_from_pointcloud"):
        q += 60.0
    if obj.get("geom_extents"):
        q += 25.0
    return q


def reject_head_blob(
    bbox: List[int],
    ys,
    xs,
    depth,
    sat,
    val,
    relief,
    h: int,
    w: int,
) -> bool:
    if len(ys) < 8:
        return True
    sm = float(np.mean(sat[ys, xs]))
    vm = float(np.mean(val[ys, xs]))
    if sm < HEAD_MIN_BLOB_SAT or vm < HEAD_MIN_BLOB_VAL:
        return True
    dvals = depth[ys, xs]
    dvals = dvals[(dvals > DEPTH_MIN) & (dvals < DEPTH_MAX)]
    if len(dvals) < 5:
        return True
    if float(np.std(dvals)) > HEAD_MAX_DEPTH_STD:
        return True
    depth_m = float(np.median(dvals))
    if is_edge_phantom(bbox, depth_m, w):
        return True
    if is_shadow(ys, xs, sat, val, relief, len(ys), h, w):
        return True
    x1, y1, x2, y2 = bbox
    if y2 < h * 0.48:
        return True
    return False
