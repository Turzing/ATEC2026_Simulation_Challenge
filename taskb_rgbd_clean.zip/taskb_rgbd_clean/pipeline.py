"""双摄 RGB-D: EE 导航 + Head 抓取。"""

from __future__ import annotations

from typing import List, Optional

import numpy as np

from config import BIN_CENTER, BIN_RADIUS, GRASP_PHASE_DIST_M, TOTAL_OBJECTS
from detector import RgbdDetector
from obs_io import RobotOdometry, parse_ee, parse_head


class _TemporalSmooth:
    def __init__(self, n: int = 5):
        self.n = n
        self._hist: dict[tuple[str, int], list[dict]] = {}

    def reset(self):
        self._hist.clear()

    def apply(self, objects: List[dict], cam: str) -> List[dict]:
        out = []
        for o in objects:
            key = (cam, int(o["id"]))
            self._hist.setdefault(key, [])
            self._hist[key].append(o)
            self._hist[key] = self._hist[key][-self.n :]
            h = self._hist[key]
            m = dict(o)
            depths = [x["depth_m"] for x in h if x.get("depth_m")]
            if depths:
                m["depth_m"] = float(np.median(depths))
            worlds = [x.get("pos_world") for x in h if x.get("pos_world")]
            if worlds:
                m["pos_world"] = np.median(np.stack(worlds), axis=0).tolist()
            if cam == "head":
                for k in ("grasp_pos_world", "grasp_quat_world"):
                    vals = [x.get(k) for x in h if x.get(k)]
                    if vals:
                        m[k] = np.median(np.stack(vals), axis=0).tolist()
            out.append(m)
        return out


class DualRgbdPipeline:
    def __init__(self):
        self.ee = RgbdDetector("ee")
        self.head = RgbdDetector("head")
        self.odom = RobotOdometry()
        self.smooth = _TemporalSmooth()

    def reset(self):
        self.ee.reset()
        self.head.reset()
        self.odom.reset()
        self.smooth.reset()

    def process(self, obs, dt: float = 0.02) -> dict:
        self.odom.update(obs, dt)
        rp, ry = self.odom.pos, self.odom.yaw

        head_objs, ee_objs = [], []
        h_rgb, h_depth = parse_head(obs)
        if h_rgb is not None and h_depth is not None:
            head_objs = self.smooth.apply(self.head.detect(h_rgb, h_depth, rp, ry), "head")

        e_rgb, e_depth = parse_ee(obs)
        if e_rgb is not None and e_depth is not None:
            ee_objs = self.smooth.apply(self.ee.detect(e_rgb, e_depth, rp, ry), "ee")

        head_tgt = head_objs[0] if head_objs else None
        ee_tgt = ee_objs[0] if ee_objs else None
        head_d = float(head_tgt["depth_m"]) if head_tgt else 999.0
        phase = "grasp" if head_d < GRASP_PHASE_DIST_M else "approach"

        return {
            "phase": phase,
            "roles": {"ee": "nav", "head": "grasp"},
            "active_camera": "head" if phase == "grasp" else "ee",
            "target_nav": ee_tgt if phase == "approach" else head_tgt,
            "target_grasp": head_tgt if phase == "grasp" else None,
            "target": head_tgt if phase == "grasp" else ee_tgt,
            "ee_objects": ee_objs,
            "ee_objects_list": ee_objs,
            "head_objects": head_objs,
            "head_objects_list": head_objs,
            "head_dist_m": head_d,
            "ee_dist_m": float(ee_tgt["depth_m"]) if ee_tgt else 999.0,
            "bin": {
                "center_world": BIN_CENTER.tolist(),
                "radius_m": float(BIN_RADIUS),
                "dist_to_robot": float(np.linalg.norm(rp[:2] - BIN_CENTER[:2])),
            },
            "robot": {"pos_world": rp.tolist(), "yaw": ry},
            "gripper": {"is_holding": False, "width": 0.04},
            "progress": {"total": TOTAL_OBJECTS, "inside_bin": 0, "remaining": TOTAL_OBJECTS},
        }

    def get_debug(self, camera: str, name: str):
        return (self.head if camera == "head" else self.ee).get_debug(name)
