"""双摄 RGB-D: EE 导航 + Head 高精度抓取。"""

from __future__ import annotations

from typing import List, Optional

import numpy as np

from config import BIN_CENTER, BIN_RADIUS, EE_TEMPORAL_N, GRASP_PHASE_DIST_M, HEAD_TEMPORAL_N, TOTAL_OBJECTS
from detector import RgbdDetector
from ee_nav import ee_nav_quality
from head_grasp import head_grasp_quality
from obs_io import RobotOdometry, parse_ee, parse_head


class _TemporalSmooth:
    def __init__(self, n: int):
        self.n = n
        self._hist: dict[tuple[str, int], list[dict]] = {}

    def reset(self):
        self._hist.clear()

    def apply(self, objects: List[dict], cam: str) -> List[dict]:
        out = []
        for o in objects:
            key = (cam, int(o["id"]))
            self._hist.setdefault(key, [])
            self._hist[key].append(o)
            self._hist[key] = self._hist[key][-self.n :]
            h = self._hist[key]
            m = dict(o)
            for field in ("depth_m", "nav_depth_m"):
                vals = [x.get(field) or x.get("depth_m") for x in h if x.get("depth_m")]
                if vals:
                    m[field] = float(np.median(vals))
            worlds = [x.get("pos_world") for x in h if x.get("pos_world")]
            if worlds:
                m["pos_world"] = np.median(np.stack(worlds), axis=0).tolist()
            robots = [x.get("pos_robot") for x in h if x.get("pos_robot")]
            if robots:
                m["pos_robot"] = np.median(np.stack(robots), axis=0).tolist()
                pr = np.asarray(m["pos_robot"], dtype=np.float32)
                m["dist_to_robot"] = float(np.linalg.norm(pr[:2]))
            if cam == "head":
                for k in ("grasp_pos_world", "grasp_pos_robot", "grasp_quat_world"):
                    vals = [x.get(k) for x in h if x.get(k)]
                    if vals:
                        m[k] = np.median(np.stack([np.asarray(v, dtype=np.float32) for v in vals]), axis=0).tolist()
                reliable = sum(1 for x in h if x.get("grasp_reliable"))
                m["grasp_reliable"] = reliable >= max(2, len(h) // 2)
            if cam == "ee":
                confs = [x.get("class_conf") for x in h if x.get("class_conf")]
                if confs:
                    m["class_conf"] = float(np.median(confs))
                classes = [x.get("class") for x in h if x.get("class")]
                if classes:
                    m["class"] = max(set(classes), key=classes.count)
                nav_rel = sum(1 for x in h if x.get("nav_reliable"))
                m["nav_reliable"] = nav_rel >= max(2, len(h) // 2)
            out.append(m)
        return out


def _best_head_grasp(objs: List[dict]) -> Optional[dict]:
    if not objs:
        return None
    reliable = [o for o in objs if o.get("grasp_reliable")]
    pool = reliable if reliable else objs
    return max(pool, key=head_grasp_quality)


def _best_ee_nav(objs: List[dict]) -> Optional[dict]:
    if not objs:
        return None
    reliable = [o for o in objs if o.get("nav_reliable")]
    pool = reliable if reliable else objs
    return max(pool, key=ee_nav_quality)


class DualRgbdPipeline:
    def __init__(self):
        self.ee = RgbdDetector("ee")
        self.head = RgbdDetector("head")
        self.odom = RobotOdometry()
        self.head_smooth = _TemporalSmooth(HEAD_TEMPORAL_N)
        self.ee_smooth = _TemporalSmooth(EE_TEMPORAL_N)

    def reset(self):
        self.ee.reset()
        self.head.reset()
        self.odom.reset()
        self.head_smooth.reset()
        self.ee_smooth.reset()

    def process(self, obs, dt: float = 0.02) -> dict:
        self.odom.update(obs, dt)
        rp, ry = self.odom.pos, self.odom.yaw

        head_objs, ee_objs = [], []
        h_rgb, h_depth = parse_head(obs)
        if h_rgb is not None and h_depth is not None:
            raw = self.head.detect(h_rgb, h_depth, rp, ry)
            head_objs = self.head_smooth.apply(raw, "head")

        e_rgb, e_depth = parse_ee(obs)
        if e_rgb is not None and e_depth is not None:
            raw = self.ee.detect(e_rgb, e_depth, rp, ry)
            ee_objs = self.ee_smooth.apply(raw, "ee")

        head_tgt = _best_head_grasp(head_objs)
        ee_tgt = _best_ee_nav(ee_objs)
        head_d = float(head_tgt["depth_m"]) if head_tgt else 999.0
        phase = "grasp" if head_tgt and head_d < GRASP_PHASE_DIST_M else "approach"

        return {
            "phase": phase,
            "roles": {"ee": "nav", "head": "grasp"},
            "active_camera": "head" if phase == "grasp" else "ee",
            "target_nav": ee_tgt if phase == "approach" else head_tgt,
            "target_grasp": head_tgt if phase == "grasp" else None,
            "target": head_tgt if phase == "grasp" else ee_tgt,
            "ee_objects": ee_objs,
            "ee_objects_list": ee_objs,
            "head_objects": head_objs,
            "head_objects_list": head_objs,
            "head_dist_m": head_d,
            "ee_dist_m": float(ee_tgt["depth_m"]) if ee_tgt else 999.0,
            "ee_nav_reliable": bool(ee_tgt and ee_tgt.get("nav_reliable")),
            "ee_nav_quality": ee_nav_quality(ee_tgt) if ee_tgt else 0.0,
            "grasp_reliable": bool(head_tgt and head_tgt.get("grasp_reliable")),
            "head_grasp_quality": head_grasp_quality(head_tgt) if head_tgt else 0.0,
            "bin": {
                "center_world": BIN_CENTER.tolist(),
                "radius_m": float(BIN_RADIUS),
                "dist_to_robot": float(np.linalg.norm(rp[:2] - BIN_CENTER[:2])),
            },
            "robot": {"pos_world": rp.tolist(), "yaw": ry},
            "gripper": {"is_holding": False, "width": 0.04},
            "progress": {"total": TOTAL_OBJECTS, "inside_bin": 0, "remaining": TOTAL_OBJECTS},
        }

    def get_debug(self, camera: str, name: str):
        return (self.head if camera == "head" else self.ee).get_debug(name)
