# taskb_rgbd_clean — 全新 RGB-D 感知（独立目录）

**不修改、不覆盖** 原有 `taskb_perception/`。这是从零写的新方案。

## 分工

| 相机 | 职责 |
|------|------|
| EE | 远距导航 + **认类** → `ee_objects_list` 含 `class` / `class_conf` |
| Head | 近距抓取 → `target_grasp.grasp_pos_world` + `grasp_quat_world` |

## 文件

```
taskb_rgbd_clean/
├── config.py
├── geometry.py
├── classify.py          ← PCA 3D 认类 (Head + EE 共用)
├── head_grasp.py        ← Head 抓取精算
├── ee_nav.py            ← EE 导航 + 认类
├── obs_io.py
├── detector.py
├── pipeline.py
├── solution.py
├── test_offline.py
└── run_sim_dual.py
```

## 本机 (无独显)

只做语法/逻辑检查，不启动 Isaac：

```bash
cd taskb_rgbd_clean
python test_offline.py
```

## Head 精度要点

1. **点云**: 深度离群剔除 → 底边 28% 像素定横向 → Z 42% 分位定高度
2. **抓取点**: 点云 Z 88% 分位 − 3cm → 夹爪指尖补偿到 gripper_base
3. **认类**: PCA 三边长 vs YCB 模板 (瓶/盒/蕉) + 2D 形状回退
4. **滤波**: 影子/边缘假检剔除 + 8 帧中值平滑 grasp 位姿
5. **选目标**: 按 `grasp_reliable` + 认类置信度 + 点云点数, 不只按距离

## 给师姐 (GPU 机器)

```bash
conda activate isaaclab
cd ATEC2026_Simulation_Challenge/taskb_rgbd_clean
python run_sim_dual.py --policy ../demo/policy.pt
```

## 给运动层

```python
from pipeline import DualRgbdPipeline
out = DualRgbdPipeline().process(obs)
# approach: out["target_nav"]
# grasp:    out["target_grasp"]
```

## 恢复旧 taskb_perception

若之前目录被改过，可用仓库内备份恢复：

```
ATEC2026_Simulation_Challenge_RIL-s/ATEC2026_Simulation_Challenge_RIL-myq/taskb_perception/
```

或解压你本地的 `taskb_perception.zip`，**不要覆盖** `taskb_rgbd_clean/`。
