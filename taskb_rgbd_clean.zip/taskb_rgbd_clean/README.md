# taskb_rgbd_clean — 全新 RGB-D 感知（独立目录）

**不修改、不覆盖** 原有 `taskb_perception/`。这是从零写的新方案。

## 分工

| 相机 | 职责 |
|------|------|
| EE | 远距导航 → `target_nav` / `ee_objects_list` |
| Head | 近距抓取 → `target_grasp.grasp_pos_world` + `grasp_quat_world` |

## 文件

```
taskb_rgbd_clean/
├── config.py
├── geometry.py
├── obs_io.py
├── detector.py
├── pipeline.py
├── solution.py
├── test_offline.py      ← 纯 CPU，任意电脑可跑
└── run_sim_dual.py      ← 需要 GPU + Isaac Sim，师姐电脑跑
```

## 本机 (无独显)

只做语法/逻辑检查，不启动 Isaac：

```bash
cd taskb_rgbd_clean
python test_offline.py
```

## 师姐电脑 (有 NVIDIA GPU)

```bash
conda activate isaaclab
cd ATEC2026_Simulation_Challenge/taskb_rgbd_clean
python run_sim_dual.py --policy ../demo/policy.pt
```

## 给运动层

```python
from pipeline import DualRgbdPipeline
out = DualRgbdPipeline().process(obs)
# approach: out["target_nav"]
# grasp:    out["target_grasp"]
```

## 恢复旧 taskb_perception

若之前目录被改过，可用仓库内备份恢复：

```
ATEC2026_Simulation_Challenge_RIL-s/ATEC2026_Simulation_Challenge_RIL-myq/taskb_perception/
```

或解压你本地的 `taskb_perception.zip`，**不要覆盖** `taskb_rgbd_clean/`。
