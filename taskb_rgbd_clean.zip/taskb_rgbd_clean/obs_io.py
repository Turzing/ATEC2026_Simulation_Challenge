"""解析仿真 obs。"""

from __future__ import annotations

import numpy as np

from config import ROBOT_INIT_POS, ROBOT_INIT_YAW, SLICE_ANG_VEL, SLICE_GRAVITY, SLICE_LIN_VEL, YAW_FUSION_ALPHA
from geometry import yaw_from_gravity


def to_numpy(x) -> np.ndarray:
    if hasattr(x, "device") and getattr(x, "device", None) is not None and x.device.type == "cuda":
        x = x.cpu()
    return np.asarray(x)


def sanitize_depth(depth: np.ndarray, max_m: float = 49.5) -> np.ndarray:
    d = depth.astype(np.float32).copy()
    bad = ~np.isfinite(d) | (d <= 0.01) | (d > max_m)
    d[bad] = 0.0
    return d


def parse_rgbd(obs: dict, rgb_key: str, depth_key: str):
    try:
        rgb = to_numpy(obs["image"][rgb_key]).squeeze()
        if rgb.ndim == 4:
            rgb = rgb[0]
        rgb = rgb[..., :3].astype(np.uint8)
        dep = to_numpy(obs["image"][depth_key]).squeeze()
        if dep.ndim == 3:
            dep = dep[..., 0]
        return rgb, sanitize_depth(dep)
    except (KeyError, TypeError, AttributeError):
        return None, None


def parse_head(obs: dict):
    return parse_rgbd(obs, "head_rgb", "head_depth")


def parse_ee(obs: dict):
    return parse_rgbd(obs, "ee_rgb", "ee_depth")


class RobotOdometry:
    def __init__(self):
        self.pos = ROBOT_INIT_POS.copy()
        self.yaw = float(ROBOT_INIT_YAW)

    def reset(self):
        self.pos = ROBOT_INIT_POS.copy()
        self.yaw = float(ROBOT_INIT_YAW)

    def update(self, obs: dict, dt: float = 0.02) -> None:
        try:
            p = to_numpy(obs["proprio"]).astype(np.float32).reshape(-1)
        except (KeyError, TypeError, ValueError):
            return
        if p.size < 12:
            return
        lin, ang, grav = p[SLICE_LIN_VEL], p[SLICE_ANG_VEL], p[SLICE_GRAVITY]
        c, s = np.cos(self.yaw), np.sin(self.yaw)
        rot = np.array([[c, -s], [s, c]], dtype=np.float32)
        dxy = rot @ lin[:2] * dt
        self.pos[0] += dxy[0]
        self.pos[1] += dxy[1]
        self.pos[2] = ROBOT_INIT_POS[2]
        yaw_g = yaw_from_gravity(grav)
        yaw_i = self.yaw + ang[2] * dt
        a = YAW_FUSION_ALPHA
        self.yaw = float((a * yaw_g + (1 - a) * yaw_i + np.pi) % (2 * np.pi) - np.pi)
