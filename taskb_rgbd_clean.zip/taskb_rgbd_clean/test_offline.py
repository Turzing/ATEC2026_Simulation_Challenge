"""离线冒烟 — 纯 CPU，无需 GPU / Isaac Sim。"""

import numpy as np

from classify import classify_object
from head_grasp import compute_head_pose, head_grasp_quality
from pipeline import DualRgbdPipeline


def _fake_obs():
    h, w = 480, 640
    rgb = np.zeros((h, w, 3), dtype=np.uint8)
    rgb[300:360, 280:360] = [220, 200, 40]
    depth = np.full((h, w), 2.5, dtype=np.float32)
    depth[300:360, 280:360] = 0.95
    proprio = np.zeros(72, dtype=np.float32)
    proprio[9:12] = [0.0, 0.0, -1.0]
    return {
        "image": {"head_rgb": rgb, "head_depth": depth, "ee_rgb": rgb, "ee_depth": depth},
        "proprio": proprio,
    }


def test_classify():
    bbox = [280, 300, 360, 360]
    pts = np.random.randn(40, 3).astype(np.float32) * 0.03 + np.array([1.0, 0.1, -0.5])
    cls, conf, ext = classify_object(bbox, 2000, pts, 80.0, 0.95)
    assert cls in ("sugar_box", "mustard_bottle", "banana")
    assert conf > 0.3


def test_head_pose():
    h, w = 480, 640
    depth = np.full((h, w), 2.5, dtype=np.float32)
    depth[300:360, 280:360] = 0.92
    ys, xs = np.mgrid[300:360, 280:360]
    ys, xs = ys.ravel(), xs.ravel()
    rp = np.array([-10.0, -10.0, 0.68], dtype=np.float32)
    pose = compute_head_pose(ys, xs, depth, 0.92, [280, 300, 360, 360], 75.0, rp, 0.0)
    assert pose is not None
    assert "grasp_pos_world" in pose
    assert "grasp_quat_world" in pose
    assert pose.get("grasp_reliable") or pose.get("pos_from_pointcloud")


def test_pipeline():
    out = DualRgbdPipeline().process(_fake_obs())
    assert out["phase"] in ("approach", "grasp")
    ee = out.get("ee_objects_list") or []
    if ee:
        assert ee[0].get("class") in ("sugar_box", "mustard_bottle", "banana")
        assert "class_conf" in ee[0]


if __name__ == "__main__":
    test_classify()
    test_head_pose()
    test_pipeline()
    print("OK — Head 精度模块离线检查通过")
