"""离线冒烟 — 纯 CPU，无 Isaac Sim。"""

import numpy as np

from pipeline import DualRgbdPipeline


def _fake_obs():
    h, w = 480, 640
    rgb = np.zeros((h, w, 3), dtype=np.uint8)
    rgb[280:340, 280:360] = [220, 200, 40]
    depth = np.full((h, w), 2.5, dtype=np.float32)
    depth[280:340, 280:360] = 1.2
    proprio = np.zeros(72, dtype=np.float32)
    proprio[9:12] = [0.0, 0.0, -1.0]
    return {
        "image": {"head_rgb": rgb, "head_depth": depth, "ee_rgb": rgb, "ee_depth": depth},
        "proprio": proprio,
    }


if __name__ == "__main__":
    out = DualRgbdPipeline().process(_fake_obs())
    assert "phase" in out and "target_nav" in out
    print("OK", out["phase"], "head_d=", out["head_dist_m"])
