"""像素 ↔ 机器人 ↔ 世界坐标变换 + 夹爪 IK 补偿。"""

from __future__ import annotations

import numpy as np

from config import (
    DEFAULT_GRASP_QUAT,
    EE_CAM,
    EE_CAM_POS,
    EE_CAM_ROT,
    GRASP_DEPTH_OFFSET,
    GRASP_FIXED_QUAT,
    GRASP_Z_PERCENTILE,
    GRIPPER_TIP_OFFSET_M,
    HEAD_CAM,
    HEAD_CAM_POS,
    HEAD_CAM_ROT,
)


def pixel_to_cam(u: float, v: float, z: float, cam: dict) -> np.ndarray:
    x = (u - cam["cx"]) / cam["fx"] * z
    y = (v - cam["cy"]) / cam["fy"] * z
    return np.array([x, y, z], dtype=np.float32)


def pixel_to_robot(u: float, v: float, z: float, camera: str) -> np.ndarray:
    cam = HEAD_CAM if camera == "head" else EE_CAM
    pos = HEAD_CAM_POS if camera == "head" else EE_CAM_POS
    rot = HEAD_CAM_ROT if camera == "head" else EE_CAM_ROT
    return pos + rot @ pixel_to_cam(u, v, z, cam)


def robot_to_world(p_robot, robot_pos: np.ndarray, robot_yaw: float) -> np.ndarray:
    p = np.asarray(p_robot, dtype=np.float32).reshape(3)
    c, s = np.cos(robot_yaw), np.sin(robot_yaw)
    rot = np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]], dtype=np.float32)
    return robot_pos + rot @ p


def world_to_robot(p_world, robot_pos: np.ndarray, robot_yaw: float) -> np.ndarray:
    pw = np.asarray(p_world, dtype=np.float32).reshape(3)
    dx, dy = pw[0] - robot_pos[0], pw[1] - robot_pos[1]
    c, s = np.cos(robot_yaw), np.sin(robot_yaw)
    return np.array([c * dx + s * dy, -s * dx + c * dy, pw[2] - robot_pos[2]], dtype=np.float32)


def yaw_from_gravity(gravity: np.ndarray) -> float:
    g = np.asarray(gravity, dtype=np.float32).reshape(3)
    n = float(np.linalg.norm(g[:2]))
    if n < 1e-4:
        return 0.0
    return float(np.arctan2(-g[1], -g[0]))


def quat_from_yaw(yaw: float) -> np.ndarray:
    h = yaw * 0.5
    return np.array([np.cos(h), 0.0, 0.0, np.sin(h)], dtype=np.float32)


def quat_mul(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    w1, x1, y1, z1 = a
    w2, x2, y2, z2 = b
    return np.array([
        w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2,
        w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2,
        w1 * y2 - x1 * z2 + y1 * w2 + z1 * x2,
        w1 * z2 + x1 * y2 - y1 * x2 + z1 * w2,
    ], dtype=np.float32)


def quat_rotate_vec(q_wxyz, v) -> np.ndarray:
    q = np.asarray(q_wxyz, dtype=np.float32).reshape(4)
    v = np.asarray(v, dtype=np.float32).reshape(3)
    w, qx, qy, qz = q
    qv = np.array([qx, qy, qz], dtype=np.float32)
    t = 2.0 * np.cross(qv, v)
    return (v + w * t + np.cross(qv, t)).astype(np.float32)


def grasp_quat(class_name: str, pos_world: np.ndarray, robot_pos: np.ndarray) -> np.ndarray:
    fixed = GRASP_FIXED_QUAT.get(class_name, DEFAULT_GRASP_QUAT)
    dx = float(pos_world[0] - robot_pos[0])
    dy = float(pos_world[1] - robot_pos[1])
    return quat_mul(quat_from_yaw(float(np.arctan2(dy, dx))), fixed)


def points_from_mask(ys, xs, depth, camera: str, *, z_min=0.14, z_max=11.0):
    pts = []
    step = 1 if len(ys) < 400 else 2
    for y, x in zip(ys[::step], xs[::step]):
        z = float(depth[y, x])
        if z_min < z < z_max:
            pts.append(pixel_to_robot(float(x), float(y), z, camera))
    if len(pts) < 8:
        return None
    return np.stack(pts, axis=0).astype(np.float32)


def object_pose_from_points(pts, robot_pos, robot_yaw, class_name: str) -> dict:
    center = np.median(pts, axis=0).astype(np.float32)
    grasp = center.copy()
    grasp[2] = float(np.percentile(pts[:, 2], GRASP_Z_PERCENTILE)) - GRASP_DEPTH_OFFSET
    pos_w = robot_to_world(center, robot_pos, robot_yaw)
    grasp_w = robot_to_world(grasp, robot_pos, robot_yaw)
    return {
        "pos_robot": center.tolist(),
        "pos_world": pos_w.tolist(),
        "grasp_pos_robot": grasp.tolist(),
        "grasp_pos_world": grasp_w.tolist(),
        "grasp_quat_world": grasp_quat(class_name, pos_w, robot_pos).tolist(),
        "dist_to_robot": float(np.linalg.norm(center[:2])),
        "yaw_rel": float(np.arctan2(center[1], center[0])),
    }


def compensate_gripper_base(obj: dict, robot_pos: np.ndarray, robot_yaw: float) -> dict:
    """指尖接触点 → gripper_base IK 目标 (沿夹爪 +Z 回退)."""
    out = dict(obj)
    contact_w = out.get("grasp_pos_world")
    if contact_w is None:
        return out
    contact_w = np.asarray(contact_w, dtype=np.float32)
    gq = out.get("grasp_quat_world")
    if gq is not None:
        z_world = quat_rotate_vec(gq, np.array([0.0, 0.0, 1.0], dtype=np.float32))
        zn = float(np.linalg.norm(z_world))
        if zn > 1e-4:
            z_world = z_world / zn
        base_w = contact_w - z_world * float(GRIPPER_TIP_OFFSET_M)
    else:
        contact_r = np.asarray(out.get("grasp_pos_robot", contact_w), dtype=np.float32)
        horiz = float(np.hypot(contact_r[0], contact_r[1]))
        if horiz < 0.05:
            return out
        dxy = contact_r[:2] / horiz
        base_r = contact_r - np.array([dxy[0] * GRIPPER_TIP_OFFSET_M, dxy[1] * GRIPPER_TIP_OFFSET_M, 0.0])
        base_w = robot_to_world(base_r, robot_pos, robot_yaw)
    out["grasp_tip_contact_world"] = contact_w.tolist()
    out["grasp_pos_world"] = base_w.tolist()
    out["grasp_pos_robot"] = world_to_robot(base_w, robot_pos, robot_yaw).tolist()
    return out
