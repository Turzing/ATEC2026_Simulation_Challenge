"""EE 导航 + 认类: 侧视 RGB-D 点云 + PCA 3D / 2D 回退。"""

from __future__ import annotations

from typing import List, Optional

import numpy as np

from classify import classify_object
from config import (
    DEPTH_MAX,
    DEPTH_MIN,
    EE_DEPTH_TOL_FAR,
    EE_DEPTH_TOL_NEAR,
    EE_FAR_DEPTH_M,
    EE_MAX_DEPTH_STD,
    EE_MIN_BLOB_SAT,
    EE_MIN_BLOB_VAL,
    EE_MIN_CLASS_CONF,
    EE_MIN_POINTS,
    EE_MIN_POINTS_3D,
    EE_SKY_CY_FRAC,
    OBJECT_SIZES,
)
from geometry import pixel_to_robot, points_from_mask, robot_to_world


def _depth_tol(depth_m: float) -> float:
    return EE_DEPTH_TOL_NEAR if depth_m < EE_FAR_DEPTH_M else EE_DEPTH_TOL_FAR


def filter_pixels_by_depth(ys, xs, depth, depth_m: float):
    d = depth[ys, xs]
    ok = (d > DEPTH_MIN) & (d < DEPTH_MAX)
    if int(np.sum(ok)) < EE_MIN_POINTS:
        return ys, xs
    d_med = float(np.median(d[ok]))
    tol = _depth_tol(depth_m)
    keep = ok & (d <= d_med + tol) & (d >= d_med - tol * 0.50)
    if int(np.sum(keep)) >= max(5, EE_MIN_POINTS // 2):
        return ys[keep], xs[keep]
    return ys, xs


def build_pointcloud(ys, xs, depth, depth_m: float) -> Optional[np.ndarray]:
    ys, xs = filter_pixels_by_depth(ys, xs, depth, depth_m)
    return points_from_mask(ys, xs, depth, "ee", z_min=DEPTH_MIN, z_max=DEPTH_MAX)


def robust_depth(ys, xs, depth, bbox: List[int]) -> Optional[float]:
    d = depth[ys, xs]
    d = d[(d > DEPTH_MIN) & (d < DEPTH_MAX)]
    if len(d) < 4:
        return None
    d_p38 = float(np.percentile(d, 38))
    x1, y1, x2, y2 = bbox
    iw, ih = max(1, x2 - x1 + 1), max(1, y2 - y1 + 1)
    inner = depth[y1 + ih // 4 : y2 - ih // 4 + 1, x1 + iw // 4 : x2 - iw // 4 + 1]
    inner = inner[(inner > DEPTH_MIN) & (inner < DEPTH_MAX)]
    d_inner = float(np.median(inner)) if len(inner) >= 3 else d_p38
    out = float(np.median([d_p38, d_inner]))
    blob_d = depth[ys, xs]
    blob_d = blob_d[(blob_d > DEPTH_MIN) & (blob_d < DEPTH_MAX)]
    if blob_d.size >= 6 and float(np.median(blob_d)) < 1.45:
        out = float(np.percentile(blob_d, 22))
    return out


def is_sky_phantom(bbox: List[int], depth_m: float, cy: float, img_h: int, img_w: int) -> bool:
    x1, y1, x2, y2 = bbox
    if y2 < img_h * 0.52:
        return True
    if cy < img_h * EE_SKY_CY_FRAC and depth_m < 2.4:
        return True
    cx = 0.5 * (x1 + x2)
    if cy < img_h * 0.28 and (cx < img_w * 0.12 or cx > img_w * 0.88):
        return True
    return False


def reject_ee_blob(bbox, ys, xs, depth, sat, val, cy, h, w) -> bool:
    if len(ys) < 6:
        return True
    sm = float(np.mean(sat[ys, xs]))
    vm = float(np.mean(val[ys, xs]))
    if sm < EE_MIN_BLOB_SAT:
        return True
    if vm < EE_MIN_BLOB_VAL and sm < 34:
        return True
    dvals = depth[ys, xs]
    dvals = dvals[(dvals > DEPTH_MIN) & (dvals < DEPTH_MAX)]
    if len(dvals) < 4:
        return True
    depth_m = float(np.median(dvals))
    if float(np.std(dvals)) > EE_MAX_DEPTH_STD:
        return True
    if is_sky_phantom(bbox, depth_m, cy, h, w):
        return True
    return False


def compute_ee_object(
    ys,
    xs,
    depth,
    depth_m: float,
    bbox: List[int],
    sat_mean: float,
    robot_pos: np.ndarray,
    robot_yaw: float,
) -> Optional[dict]:
    area = len(ys)
    cx, cy = float(np.median(xs)), float(np.median(ys))
    pts = build_pointcloud(ys, xs, depth, depth_m)

    use_3d = pts is not None and (
        len(pts) >= EE_MIN_POINTS_3D or (depth_m < 1.35 and len(pts) >= EE_MIN_POINTS)
    )
    cls, cls_conf, geom_ext = classify_object(
        bbox, area, pts if use_3d else None, sat_mean, depth_m,
    )

    if pts is not None and len(pts) >= EE_MIN_POINTS:
        center = np.median(pts, axis=0).astype(np.float32)
        from_pc = True
        pt_count = len(pts)
    else:
        center = pixel_to_robot(cx, cy, depth_m, "ee")
        from_pc = False
        pt_count = area

    if float(center[2]) < -0.78 or float(center[2]) > 0.30:
        return None

    pos_w = robot_to_world(center, robot_pos, robot_yaw)
    nav_reliable = from_pc and pt_count >= EE_MIN_POINTS and depth_m < 3.5
    if use_3d and cls_conf >= EE_MIN_CLASS_CONF:
        nav_reliable = True

    conf = float(min(0.94, 0.42 + cls_conf * 0.52 + (0.08 if from_pc else 0.0)))

    out = {
        "class": cls,
        "class_conf": cls_conf,
        "conf": conf,
        "pos_robot": center.tolist(),
        "pos_world": pos_w.tolist(),
        "dist_to_robot": float(np.linalg.norm(center[:2])),
        "yaw_rel": float(np.arctan2(center[1], center[0])),
        "depth_m": depth_m,
        "nav_depth_m": depth_m,
        "nav_yaw_rel": float(np.arctan2(center[1], center[0])),
        "centroid_uv": [cx, cy],
        "nav_point_count": pt_count,
        "pos_from_pointcloud": from_pc,
        "nav_reliable": nav_reliable,
        "world_reliable": depth_m < 2.5 and from_pc,
    }
    if geom_ext is not None:
        out["geom_extents"] = geom_ext
    return out


def ee_nav_quality(obj: dict) -> float:
    q = float(obj.get("class_conf", 0)) * 100.0
    q += float(obj.get("blob_sat_mean", 0)) * 0.4
    q += float(obj.get("nav_point_count", 0)) * 0.25
    if obj.get("nav_reliable"):
        q += 80.0
    if obj.get("geom_extents"):
        q += 20.0
    q -= float(obj.get("depth_m", 99.0)) * 2.0
    return q
