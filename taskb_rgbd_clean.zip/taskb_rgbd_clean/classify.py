"""Head / EE 共用: PCA 3D 认类 + 2D 形状回退。"""

from __future__ import annotations

from typing import List, Optional, Tuple

import numpy as np

from config import (
    CLASS_RATIO_TEMPLATES,
    GEOM_MATCH_SIGMA,
    MIN_CLASS_MARGIN,
    OBJECT_SIZES,
    RATIO_MATCH_SIGMA,
)


def _template_extents(name: str) -> np.ndarray:
    lx, ly, lz = OBJECT_SIZES[name]
    return np.sort([lx, ly, lz]).astype(np.float32)


def _pca_extents(pts: np.ndarray) -> np.ndarray:
    centered = pts - np.mean(pts, axis=0)
    if len(centered) < 8:
        return np.sort(np.ptp(pts, axis=0)).astype(np.float32)
    try:
        _, _, vt = np.linalg.svd(centered, full_matrices=False)
        ext = np.ptp(centered @ vt.T, axis=0)
    except np.linalg.LinAlgError:
        ext = np.ptp(pts, axis=0)
    return np.sort(np.maximum(ext, 1e-4)).astype(np.float32)


def _extent_ratios(ext: np.ndarray) -> tuple[float, float, float]:
    e0, e1, e2 = float(ext[0]), float(ext[1]), float(ext[2])
    return e1 / max(e0, 1e-4), e2 / max(e1, 1e-4), e0 / max(e2, 1e-4)


def _score_3d(ext: np.ndarray) -> dict[str, float]:
    r10, r21, flat = _extent_ratios(ext)
    scores: dict[str, float] = {}
    for name in OBJECT_SIZES:
        t = _template_extents(name)
        d_ext = float(np.linalg.norm(ext - t))
        s_ext = float(np.exp(-(d_ext / GEOM_MATCH_SIGMA) ** 2))
        tr10, tr21 = CLASS_RATIO_TEMPLATES[name]
        d_ratio = float(np.hypot(r10 - tr10, r21 - tr21))
        s_ratio = float(np.exp(-(d_ratio / RATIO_MATCH_SIGMA) ** 2))
        scores[name] = 0.38 * s_ext + 0.62 * s_ratio
    if r10 < 1.18:
        scores["banana"] = scores.get("banana", 0) * 1.55
        scores["sugar_box"] = scores.get("sugar_box", 0) * 0.75
    if flat < 0.26 and r10 > 1.35:
        scores["sugar_box"] = scores.get("sugar_box", 0) * 1.45
    if 1.25 < r10 < 1.65 and 1.9 < r21 < 2.8:
        scores["mustard_bottle"] = scores.get("mustard_bottle", 0) * 1.40
    total = sum(scores.values()) + 1e-6
    return {k: v / total for k, v in scores.items()}


def classify_2d(bbox: List[int], area: int, depth_m: float) -> Tuple[str, float]:
    x1, y1, x2, y2 = bbox
    bw, bh = max(1, x2 - x1 + 1), max(1, y2 - y1 + 1)
    asp = max(bw, bh) / min(bw, bh)
    fill = area / max(bw * bh, 1)
    vert, horiz = bh >= bw * 1.20, bw >= bh * 1.20
    if fill > 0.36 and asp < 1.50:
        return "sugar_box", 0.72 if depth_m < 1.30 else 0.65
    if vert and asp >= 1.32:
        return "mustard_bottle", min(0.86, 0.56 + 0.11 * (asp - 1.32))
    if horiz and asp >= 1.22:
        return "banana", min(0.84, 0.54 + 0.13 * (asp - 1.22))
    if asp >= 1.72:
        return ("mustard_bottle", 0.64) if vert else ("banana", 0.66)
    if asp < 1.16:
        return "sugar_box", 0.60
    return "sugar_box", 0.55


def classify_object(
    bbox: List[int],
    area: int,
    pts: Optional[np.ndarray],
    sat_mean: float,
    depth_m: float,
) -> Tuple[str, float, Optional[List[float]]]:
    """Head 主认类: 点云 PCA 与 YCB 模板匹配, 不够点时 2D 回退."""
    name_2d, conf_2d = classify_2d(bbox, area, depth_m)
    if pts is None or len(pts) < 12:
        return name_2d, conf_2d * 0.88, None

    ext = _pca_extents(pts)
    e0, e1, e2 = float(ext[0]), float(ext[1]), float(ext[2])
    if (e0 < 0.045 and e1 < 0.08) or e2 < 0.025:
        return name_2d, conf_2d, ext.tolist()

    scores = _score_3d(ext)
    ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    best, s1 = ranked[0]
    s2 = ranked[1][1] if len(ranked) > 1 else 0.0
    margin = s1 - s2
    conf = float(min(0.94, 0.5 + margin * 1.2 + min(0.15, len(pts) / 200.0)))
    if margin < MIN_CLASS_MARGIN:
        if conf_2d >= 0.50:
            return name_2d, conf_2d * 0.88, ext.tolist()
        return name_2d, conf * 0.7, ext.tolist()
    return best, conf, ext.tolist()
