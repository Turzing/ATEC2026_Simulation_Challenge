"""Task B 感知常量 — 来自 Isaac Lab B2-Piper。"""

from __future__ import annotations

import numpy as np

HEAD_CAM = dict(fx=733.27, fy=733.27, cx=320.0, cy=240.0, w=640, h=480)
EE_CAM = dict(fx=458.29, fy=458.29, cx=320.0, cy=240.0, w=640, h=480)

HEAD_CAM_POS = np.array([0.422, 0.025, 0.062], dtype=np.float32)
EE_CAM_POS = np.array([-0.05, 0.0, 0.06], dtype=np.float32)
HEAD_CAM_PITCH = np.deg2rad(-30.0)


def _head_rot() -> np.ndarray:
    cp, sp = np.cos(HEAD_CAM_PITCH), np.sin(HEAD_CAM_PITCH)
    r_pitch = np.array([[1, 0, 0], [0, cp, -sp], [0, sp, cp]], dtype=np.float32)
    r_swap = np.array([[0, 0, 1], [1, 0, 0], [0, -1, 0]], dtype=np.float32)
    return r_swap @ r_pitch


HEAD_CAM_ROT = _head_rot()
EE_CAM_ROT = np.array([[-1, 0, 0], [0, 0, 1], [0, -1, 0]], dtype=np.float32)

ROBOT_INIT_POS = np.array([-10.0, -10.0, 0.68], dtype=np.float32)
ROBOT_INIT_YAW = 0.0
BIN_CENTER = np.array([-3.0, -10.0, 0.0], dtype=np.float32)
BIN_RADIUS = 1.0
TOTAL_OBJECTS = 18

# ── 抓取 ──
GRASP_DEPTH_OFFSET = 0.03
GRASP_Z_PERCENTILE = 88
GRASP_PHASE_DIST_M = 1.10
GRIPPER_TIP_OFFSET_M = 0.12

GRASP_FIXED_QUAT = {
    "sugar_box": np.array([0.707, 0.0, 0.707, 0.0], dtype=np.float32),
    "mustard_bottle": np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float32),
    "banana": np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float32),
}
DEFAULT_GRASP_QUAT = np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float32)

OBJECT_SIZES = {
    "sugar_box": (0.175, 0.098, 0.039),
    "mustard_bottle": (0.189, 0.082, 0.057),
    "banana": (0.195, 0.040, 0.040),
}

# ── Head 精度参数 ──
DEPTH_MIN = 0.14
DEPTH_MAX = 11.0
MIN_HEAD_POINTS = 12
HEAD_BOTTOM_FRAC = 0.72       # bbox 底 28% 像素定横向
HEAD_CENTER_Z_PCT = 42         # 物体中心高度分位
HEAD_DEPTH_POINT_TOL = 0.095   # 点云深度离群剔除
HEAD_MIN_BLOB_SAT = 38
HEAD_MIN_BLOB_VAL = 42
HEAD_MAX_DEPTH_STD = 0.085
HEAD_MIN_GRASP_CONF = 0.52

# ── 认类 ──
MIN_CLASS_MARGIN = 0.12
GEOM_MATCH_SIGMA = 0.055
RATIO_MATCH_SIGMA = 0.42
CLASS_RATIO_TEMPLATES = {
    "sugar_box": (1.55, 2.10),
    "mustard_bottle": (1.42, 2.35),
    "banana": (1.08, 2.85),
}

SLICE_LIN_VEL = slice(0, 3)
SLICE_ANG_VEL = slice(3, 6)
SLICE_GRAVITY = slice(9, 12)
YAW_FUSION_ALPHA = 0.8

# ── EE 导航/认类 ──
EE_MIN_POINTS = 8
EE_MIN_POINTS_3D = 18
EE_DEPTH_TOL_NEAR = 0.11
EE_DEPTH_TOL_FAR = 0.24
EE_FAR_DEPTH_M = 2.0
EE_MIN_BLOB_SAT = 26
EE_MIN_BLOB_VAL = 38
EE_MAX_DEPTH_STD = 0.095
EE_SKY_CY_FRAC = 0.38
EE_MIN_CLASS_CONF = 0.40

# 时域平滑帧数
HEAD_TEMPORAL_N = 8
EE_TEMPORAL_N = 5
