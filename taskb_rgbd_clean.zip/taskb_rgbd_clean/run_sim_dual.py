"""
Isaac Sim 双摄联调 — 请在有 NVIDIA 显卡的机器上运行 (师姐电脑)

用法:
    conda activate isaaclab
    cd ATEC2026_Simulation_Challenge/taskb_rgbd_clean
    python run_sim_dual.py --policy ../demo/policy.pt

操作: 点 Isaac 窗口 → WASD 移动 → P 存图 → Q 退出
"""

import argparse
import os
import sys

import cv2
import numpy as np
from isaaclab.app import AppLauncher

parser = argparse.ArgumentParser()
parser.add_argument("--task", default="ATEC-TaskB-B2Piper")
parser.add_argument("--out", default="./debug_out")
parser.add_argument("--policy", default="")
AppLauncher.add_app_launcher_args(parser)
args, _ = parser.parse_known_args()
if not getattr(args, "enable_cameras", False):
    args.enable_cameras = True

app = AppLauncher(args).app

import gymnasium as gym
from isaaclab.envs import multi_agent_to_single_agent
from isaaclab_tasks.utils import parse_env_cfg
import atec_rl_lab.tasks  # noqa: F401

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pipeline import DualRgbdPipeline


def draw(vis, objs, prefix=""):
    for o in objs:
        x1, y1, x2, y2 = map(int, o["bbox"])
        cv2.rectangle(vis, (x1, y1), (x2, y2), (0, 255, 0), 2)
        lab = f"{prefix}{o['id']} z={o.get('depth_m', 0):.2f}"
        cv2.putText(vis, lab, (x1, max(12, y1 - 4)), 0, 0.45, (0, 255, 0), 1)


def main():
    os.makedirs(args.out, exist_ok=True)
    cfg = parse_env_cfg(args.task, device=args.device, num_envs=1)
    env = gym.make(args.task, cfg=cfg)
    try:
        from isaaclab.envs import DirectMARLEnv
        if isinstance(env.unwrapped, DirectMARLEnv):
            env = multi_agent_to_single_agent(env)
    except Exception:
        pass

    pipe = DualRgbdPipeline()
    policy = None
    if args.policy and os.path.exists(args.policy):
        import torch
        policy = torch.jit.load(args.policy, map_location=args.device)

    obs, _ = env.reset()
    frame = 0
    while app.is_running():
        out = pipe.process(obs)
        phase = out["phase"]
        img = obs["image"]["head_rgb"]
        if hasattr(img, "cpu"):
            img = img.cpu().numpy()
        img = np.asarray(img).squeeze()[..., :3]
        vis = cv2.cvtColor(img.astype(np.uint8), cv2.COLOR_RGB2BGR)
        draw(vis, out.get("head_objects", []), "H")
        txt = f"phase={phase} head_d={out['head_dist_m']:.2f} ee_d={out['ee_dist_m']:.2f}"
        cv2.putText(vis, txt, (8, 24), 0, 0.6, (0, 255, 255), 2)
        cv2.imshow("taskb_rgbd_clean", vis)
        key = cv2.waitKey(1) & 0xFF
        if key == ord("q"):
            break
        if key == ord("p"):
            cv2.imwrite(os.path.join(args.out, f"frame_{frame:05d}.png"), vis)

        if policy is not None:
            import torch
            with torch.inference_mode():
                act = policy(obs["proprio"].to(args.device)).squeeze().cpu().numpy().tolist()
        else:
            p = obs["proprio"]
            dim = (int(p.shape[-1]) - 12) // 3
            act = [0.0] * dim
        obs, _, term, trunc, _ = env.step(act)
        if term or trunc:
            obs, _ = env.reset()
            pipe.reset()
        frame += 1

    cv2.destroyAllWindows()
    env.close()


if __name__ == "__main__":
    main()
